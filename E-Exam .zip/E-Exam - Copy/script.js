const questions = [
  {
    text: "Which element produces hydrogen ion as the only positive ion when dissolved in water?",
    options: ["sulphur", "acid", "hydrogen", "boron"],
    answer: "acid"
  },
  {
    text: "Which planet is known as the Red Planet?",
    options: ["Earth", "Mars", "Jupiter", "Venus"],
    answer: "Mars"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  },
  {
    text: "What is the chemical symbol for water?",
    options: ["O2", "H2O", "CO2", "NaCl"],
    answer: "H2O"
  }
];

let currentIndex = 0;
let selectedAnswers = {};
const questionText = document.getElementById("question-text");
const optionsForm = document.getElementById("options-form");
const questionGrid = document.getElementById("question-grid");

function loadQuestion(index) {
  const question = questions[index];
  questionText.textContent = question.text;
  optionsForm.innerHTML = "";
  question.options.forEach(opt => {
    const id = `${index}-${opt}`;
    const label = document.createElement("label");
    label.innerHTML = `<input type="radio" name="question" value="${opt}" id="${id}"> ${opt}`;
    optionsForm.appendChild(label);
  });

  const selected = selectedAnswers[index];
  if (selected) {
    document.querySelector(`input[value="${selected}"]`).checked = true;
  }

  highlightActive(index);
}

optionsForm.addEventListener("change", (e) => {
  selectedAnswers[currentIndex] = e.target.value;
});

document.getElementById("next-btn").addEventListener("click", () => {
  if (currentIndex < questions.length - 1) {
    currentIndex++;
    loadQuestion(currentIndex);
  }
});

document.getElementById("prev-btn").addEventListener("click", () => {
  if (currentIndex > 0) {
    currentIndex--;
    loadQuestion(currentIndex);
  }
});

function createGrid() {
  for (let i = 0; i < 100; i++) {
    const btn = document.createElement("button");
    btn.textContent = i + 1;
    btn.addEventListener("click", () => {
      if (i < questions.length) {
        currentIndex = i;
        loadQuestion(currentIndex);
      }
    });
    questionGrid.appendChild(btn);
  }
}

function highlightActive(index) {
  const buttons = questionGrid.querySelectorAll("button");
  buttons.forEach(btn => btn.classList.remove("active"));
  buttons[index].classList.add("active");
}

document.getElementById("end-btn").addEventListener("click", () => {
  alert("CBT Ended! Submitting your answers...");
  clearInterval(timerInterval);
});

createGrid();
loadQuestion(0);

// Countdown Timer (15 minutes)
let time = 15 * 60;
const timerDisplay = document.getElementById("timer");

function updateTimer() {
  const minutes = Math.floor(time / 60);
  const seconds = time % 60;
  timerDisplay.textContent = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  time--;
  if (time < 0) {
    clearInterval(timerInterval);
    alert("Time is up! Submitting your CBT automatically.");
  }
}

const timerInterval = setInterval(updateTimer, 1000);
